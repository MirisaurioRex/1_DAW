
// Ejercicio 1.9.1 - Conversi�n de metros a millas

public class Ejercicio_1_9_1
{
	public static void Main()
	{
		// Definimos la cantidad prefijada de metros
		int metros = 3000;
		// Convertimos a millas: 1 milla = 1609 metros
		int millas = metros / 1609;
		// Mostramos el resultado
		System.Console.WriteLine(millas);
	}
}

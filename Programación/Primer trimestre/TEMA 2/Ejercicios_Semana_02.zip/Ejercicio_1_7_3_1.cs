public class Ejercicio_1_7_3_1
{
	public static void Main()
	{
		int num1 = 121, num2 = 132;
		System.Console.WriteLine(num1*num2);
	}
}

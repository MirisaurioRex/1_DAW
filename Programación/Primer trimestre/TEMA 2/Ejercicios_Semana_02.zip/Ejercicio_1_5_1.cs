public class Ejercicio_1_5_1
{
	public static void Main()
	{
		System.Console.WriteLine(118+56);
	}
}

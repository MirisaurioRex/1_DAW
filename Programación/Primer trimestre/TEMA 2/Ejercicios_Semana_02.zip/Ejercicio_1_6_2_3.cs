public class Ejercicio_1_6_2_3
{
	public static void Main()
	{
		System.Console.WriteLine(15 + -5*6 / 10);
	}
}

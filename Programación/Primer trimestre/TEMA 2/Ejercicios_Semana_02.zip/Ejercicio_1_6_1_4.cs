public class Ejercicio_1_6_1_4
{
	public static void Main()
	{
		System.Console.WriteLine(301%3);
	}
}

public class Ejercicio_1_6_1_3
{
	public static void Main()
	{
		System.Console.WriteLine(301/3);
	}
}

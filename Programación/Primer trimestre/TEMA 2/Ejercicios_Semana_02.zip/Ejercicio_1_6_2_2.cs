public class Ejercicio_1_6_2_2
{
	public static void Main()
	{
		System.Console.WriteLine((20+5)%6);
	}
}
